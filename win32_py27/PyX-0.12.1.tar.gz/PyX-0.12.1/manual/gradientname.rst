
.. _gradientname:

*************************
Appendix: Named gradients
*************************

.. _fig_gradientname:
.. figure:: gradientname.*
   :align:  center

   Names gradients

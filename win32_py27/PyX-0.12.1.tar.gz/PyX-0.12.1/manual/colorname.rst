
.. _colorname:

**********************
Appendix: Named colors
**********************

.. _fig_colorname:
.. figure:: colorname.*
   :align:  center

   Names colors

